export const CONFIG = {
  width: 800,
  height: 600,
  paddleWidth: 12,
  paddleHeight: 100,
  ballRadius: 8,
  paddleSpeed: 6,
  initialBallSpeed: 5
};